function OnApplicationStarted()
{
    $__logger.Info("OnApplicationStarted")
    # Define the base directory name where games are located
$baseDirectoryName = "Games"

# Get the path to the exclusion file, assuming it's in the same directory as the script
$exclusionFilePath = Join-Path -Path $PSScriptRoot -ChildPath "Exclusion.txt"

# Initialize the exclusion arrays
$folderExclusions = @()
$exeExclusions = @()

# Check if the exclusion file exists
if (Test-Path -Path $exclusionFilePath) {
    # Read the contents of the exclusion file
    $exclusions = Get-Content -Path $exclusionFilePath -Raw

    # Separate the folder and exe exclusions
    $folderExclusions = ($exclusions -split 'Folders:\r?\n')[1] -split '\r?\n' | Where-Object { $_ -and $_ -notmatch '^Exe:$' } | ForEach-Object { $_ -replace '^"|"$', '' }
    $exeExclusions = ($exclusions -split 'Exe:\r?\n')[1] -split '\r?\n' | Where-Object { $_ } | ForEach-Object { $_ -replace '^"|"$', '' }
}

# Get all drives
$drives = Get-PSDrive -PSProvider 'FileSystem'

# Loop through each drive
foreach ($drive in $drives) {
    # Define the path to "Test/PC/Games" on the current drive
    $baseDirectoryPath = Join-Path -Path $drive.Root -ChildPath $baseDirectoryName

    # Check if the "Games" directory exists on this drive
    if (Test-Path -Path $baseDirectoryPath) {
        # Get all game folders within the "Games" directory
        $gameFolders = Get-ChildItem -Path $baseDirectoryPath -Directory

        # Loop through each game folder
        foreach ($gameFolder in $gameFolders) {
            # Skip the folder if it's in the exclusion list
            if ($folderExclusions -contains $gameFolder.Name) {
                continue
            }

            # Format the game name by replacing hyphens with colons and extracting the release year
            $formattedName = $gameFolder.Name -replace ' - ', ': '
            $releaseYear = $null
            if ($formattedName -match '\((\d{4})\)') {
                $releaseYear = $matches[1]
                $formattedName = $formattedName -replace '\s*\(\d{4}\)', ''
            }

            # Check if the game already exists in Playnite
            $existingGame = $PlayniteAPI.Database.Games | Where-Object { $_.Name -eq $formattedName -and $_.PlatformIds -contains $platform.Id }

            if ($existingGame -and $existingGame.InstallDirectory -ne $gameFolder.FullName) {
                # Update the existing game's InstallDirectory
                $existingGame.InstallDirectory = $gameFolder.FullName
                $PlayniteAPI.Database.Games.Update($existingGame)
            } elseif (-not $existingGame) {
                # Create a new game object
                $newGame = New-Object Playnite.SDK.Models.Game
                $newGame.Name = $formattedName
                $newGame.InstallDirectory = $gameFolder.FullName
                $newGame.IsInstalled = $true
                $newGame.ReleaseDate = $releaseYear

                # Retrieve the platform GUID by name and add it to the game's platform IDs
                $platformName = "Pc (windows)"
                $platform = $PlayniteAPI.Database.Platforms | Where-Object { $_.Name -eq $platformName }
                if ($platform -ne $null) {
                    $newGame.PlatformIds = New-Object System.Collections.Generic.List[System.Guid]
                    $newGame.PlatformIds.Add($platform.Id)
                }

                # Initialize the GameActions collection
                $newGame.GameActions = New-Object System.Collections.ObjectModel.ObservableCollection[Playnite.SDK.Models.GameAction]

                # Find all .exe files in the game folder and its subfolders
                $exeFiles = Get-ChildItem -Path $gameFolder.FullName -Filter *.exe -Recurse | Where-Object {
                    # Ensure the file is not within an excluded folder
                    $currentPath = $_.DirectoryName
                    $isExcluded = $false
                    foreach ($folder in $folderExclusions) {
                        if ($currentPath -like "*\$folder*") {
                            $isExcluded = $true
                            break
                        }
                    }
                    -not $isExcluded
                }

                # Loop through each .exe file and add it as a play action, excluding 'redist' directories and exe exclusions
                foreach ($exeFile in $exeFiles) {
                    # Check if the file path contains any variation of 'redist' directory or is in the exe exclusion list
                    if (-not ($exeFile.FullName -match '\\redist\\|_redsit\\|_Redist\\|_Redist\\|\\(_redist\\)|\\(_Redist\\)') -and ($exeExclusions -notcontains $exeFile.Name)) {
                        $playAction = New-Object Playnite.SDK.Models.GameAction
                        $playAction.Name = $exeFile.BaseName
                        $playAction.Path = $exeFile.FullName
                        # Set the working directory to the directory of the .exe file
                        $playAction.WorkingDir = $exeFile.DirectoryName
                        $playAction.IsPlayAction = $true

                        # Add the play action to the game's GameActions
                        $newGame.GameActions.Add($playAction)
                    }
                }

                # Add the new game to Playnite's database
                $PlayniteAPI.Database.Games.Add($newGame)
            }
        }
    }
}
}

function OnApplicationStopped()
{
    $__logger.Info("OnApplicationStopped")
}

function OnLibraryUpdated()
{
    $__logger.Info("OnLibraryUpdated")
}

function OnGameStarting()
{
    param($evnArgs)
    $__logger.Info("OnGameStarting $($evnArgs.Game)")
}

function OnGameStarted()
{
    param($evnArgs)
    $__logger.Info("OnGameStarted $($evnArgs.Game)")
}

function OnGameStopped()
{
    param($evnArgs)
    $__logger.Info("OnGameStopped $($evnArgs.Game) $($evnArgs.ElapsedSeconds)")
}

function OnGameInstalled()
{
    param($evnArgs)
    $__logger.Info("OnGameInstalled $($evnArgs.Game)")
}

function OnGameUninstalled()
{
    param($evnArgs)
    $__logger.Info("OnGameUninstalled $($evnArgs.Game)")
}

function OnGameSelected()
{
    param($gameSelectionEventArgs)
    $__logger.Info("OnGameSelected $($gameSelectionEventArgs.OldValue) -> $($gameSelectionEventArgs.NewValue)")
}
